import React from 'react'
import MoreBestSeller from '../Components/BestSeller/MoreBestSeller'

function BestSellers() {
  return (
    <div>
        <MoreBestSeller/>
    </div>
  )
}

export default BestSellers