import React from 'react'
import CardDetail from '../Components/CardDetail/CardDetail'

function ProductDetail() {
  return (
    <div>
        <CardDetail/>
    </div>
  )
}

export default ProductDetail